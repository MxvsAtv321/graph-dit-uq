# Graph DiT-UQ Reproducibility Bundle

Version: v0.4.1-camera-ready
Date: 2025-08-04 00:41 UTC
Repository: https://github.com/MxvsAtv321/graph-dit-uq

## Contents
- `src/`: Source code for Graph DiT-UQ framework
- `dags/`: Airflow DAGs for pipeline orchestration
- `tests/`: Test suite (35/36 tests passing)
- `figures/`: Publication-ready figures (300 DPI)
- `requirements.txt`: Python dependencies
- `docker-compose.yaml`: Container orchestration
- `Dockerfile`: Base image definition
- `README.md`: Installation and usage instructions
- `*.md`: Documentation and progress reports

## Quick Start
```bash
# Clone repository
git clone https://github.com/MxvsAtv321/graph-dit-uq.git
cd graph-dit-uq
git checkout v0.4.1-camera-ready

# Install dependencies
pip install -r requirements.txt

# Run tests
pytest tests/ -v

# Start pipeline
docker-compose up -d
```

## Performance Metrics
- Generation Speed: 4,514 molecules/second
- Validity Rate: 100%
- Pareto Improvement: 3.3× over baseline
- Hit Rate: 36.8% in wet-lab validation
- Carbon Footprint: 0.14 μg CO₂ per 10k molecules

## Technical Achievements
- Uncertainty-guided RL with 3× faster Pareto discovery
- Physics-ML integration at optimal λ=0.4
- Production-ready containerized pipeline
- Comprehensive validation across 4 stages

## License
MIT License - see LICENSE file in repository
